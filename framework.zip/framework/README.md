# composer install
# composer dump-autoload
# mudar as constantes no arquivo "config/config.php"
