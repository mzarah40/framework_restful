<?php 

namespace App\Repositories;

class HomeRepository
{
	
}