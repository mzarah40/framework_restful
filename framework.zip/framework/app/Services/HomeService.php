<?php 

namespace App\Services;

use App\Repositories\HomeRepository;

class HomeService
{

}