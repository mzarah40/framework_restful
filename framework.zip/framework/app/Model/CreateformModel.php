<?php  

namespace App\Model;

class CreateformModel
{
	private $tableForms = "forms";
	private $fillable = ['name','label','enctype','onsubmit','method','action','class','skin'];

	
}