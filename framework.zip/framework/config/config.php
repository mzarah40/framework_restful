<?php 

const DEFAULT_CONTROLLER = 'Home';
const DEFAULT_METHOD     = 'index';

const DATABASE = 'framework';
const HOST     = 'localhost';
const USER     = 'root';
const PASSWORD = 'root';

const BASE_URL = 'http://localhost/framework/';

const API_KEY  = '35xs6817xrfde7e';